//
//  CalendarDetailViewController.swift
//  TabBar_ios_team_a
//
//  Created by 강민성 on 2021/02/18.
//

import UIKit

class CalendarDetailViewController: UIViewController {
    
    let videmodel = CalendarDetailViewController()
    
    
    
    
    @IBOutlet weak var workplaceImage: UIImageView!
    @IBOutlet weak var houseImage: UIImageView!
    @IBOutlet weak var calendarImage: UIImageView!
    
    
    @IBOutlet weak var workplaceLabel: UILabel!
    @IBOutlet weak var houseLabel: UILabel!
    @IBOutlet weak var calendarLabel: UILabel!
    
    
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func save(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func didSelectWorkplaceButton(_ sender: Any) {
        
    }
    
    @IBAction func didTapHouseButton(_ sender: Any) {
        
    }
    
    @IBAction func didTapCalendarButton(_ sender: Any) {
    }
    
    

}
