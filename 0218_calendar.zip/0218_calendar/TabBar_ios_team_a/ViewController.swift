import UIKit
import SQLite3
class ViewController: UIViewController {
    let db = DBHelper()
    
    override func viewDidLoad() {
    
        super.viewDidLoad()
    }
  
   
}
